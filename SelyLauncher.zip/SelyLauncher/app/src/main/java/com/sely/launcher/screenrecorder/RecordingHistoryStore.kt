package com.sely.launcher.screenrecorder

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class RecordingEntry(val uri: String, val name: String, val timestampMillis: Long)

object RecordingHistoryStore {
    private const val PREFS = "sely_screen_recordings"
    private const val KEY = "recordings"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getAll(context: Context): List<RecordingEntry> {
        val raw = prefs(context).getString(KEY, "[]") ?: "[]"
        val array = JSONArray(raw)
        val list = mutableListOf<RecordingEntry>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(RecordingEntry(obj.getString("uri"), obj.getString("name"), obj.getLong("ts")))
        }
        return list.sortedByDescending { it.timestampMillis }
    }

    fun add(context: Context, entry: RecordingEntry) {
        val current = getAll(context).toMutableList()
        current.add(0, entry)
        val array = JSONArray()
        current.forEach {
            array.put(JSONObject().apply {
                put("uri", it.uri); put("name", it.name); put("ts", it.timestampMillis)
            })
        }
        prefs(context).edit().putString(KEY, array.toString()).apply()
    }
}
