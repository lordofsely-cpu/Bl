package com.sely.launcher.appmanagement

import android.content.Context

/**
 * Sely favorites — a real, user-controlled list (package|||activity
 * entries, ordered), replacing what was previously just "the first 8
 * apps alphabetically" in the Sidebar. Toggled from App Management's
 * per-app menu.
 */
object FavoritesStore {
    private const val PREFS = "sely_favorites"
    private const val KEY_FAVORITES = "favorites"
    private const val SEP = ";;"
    private const val FIELD_SEP = "|||"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getFavorites(context: Context): List<Pair<String, String>> {
        val raw = prefs(context).getString(KEY_FAVORITES, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.split(SEP).map {
            val parts = it.split(FIELD_SEP)
            parts[0] to parts.getOrElse(1) { "" }
        }
    }

    fun isFavorite(context: Context, packageName: String) =
        getFavorites(context).any { it.first == packageName }

    fun toggleFavorite(context: Context, packageName: String, activityName: String) {
        val current = getFavorites(context).toMutableList()
        if (current.any { it.first == packageName }) {
            current.removeAll { it.first == packageName }
        } else {
            current.add(packageName to activityName)
        }
        save(context, current)
    }

    private fun save(context: Context, list: List<Pair<String, String>>) {
        val raw = list.joinToString(SEP) { "${it.first}$FIELD_SEP${it.second}" }
        prefs(context).edit().putString(KEY_FAVORITES, raw).apply()
    }
}
