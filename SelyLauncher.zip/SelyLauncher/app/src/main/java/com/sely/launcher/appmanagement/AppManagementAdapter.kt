package com.sely.launcher.appmanagement

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager

class AppManagementAdapter(
    private val context: Context,
    private val entries: List<ManagedAppInfo>,
    private val onChanged: () -> Unit
) : RecyclerView.Adapter<AppManagementAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.mgmtIcon)
        val label: TextView = view.findViewById(R.id.mgmtLabel)
        val meta: TextView = view.findViewById(R.id.mgmtMeta)
        val menu: TextView = view.findViewById(R.id.mgmtMenu)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_app_management, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = entries.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = entries[position]
        holder.icon.setImageDrawable(entry.app.icon)
        holder.label.text = entry.app.label
        holder.label.setTextColor(ThemeManager.textPrimary(context))
        val hidden = HiddenAppsStore.isHidden(context, entry.app.packageName)
        val favorite = FavoritesStore.isFavorite(context, entry.app.packageName)
        val flags = buildString {
            if (favorite) append("★ ")
            if (hidden) append("Hidden · ")
            append(entry.versionName ?: "—")
            append(" · ${AppManagementRepository.formatSize(entry.apkSizeBytes)}")
        }
        holder.meta.text = flags
        holder.meta.setTextColor(ThemeManager.textSecondary(context))
        holder.menu.setTextColor(ThemeManager.textSecondary(context))

        holder.itemView.setOnClickListener { launch(entry) }
        holder.menu.setOnClickListener { showMenu(holder.menu, entry) }
    }

    private fun launch(entry: ManagedAppInfo) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = android.content.ComponentName(entry.app.packageName, entry.app.activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    private fun showMenu(anchor: View, entry: ManagedAppInfo) {
        val hidden = HiddenAppsStore.isHidden(context, entry.app.packageName)
        val favorite = FavoritesStore.isFavorite(context, entry.app.packageName)
        val menu = PopupMenu(context, anchor)
        menu.menu.add("Open")
        menu.menu.add("App info")
        menu.menu.add(if (favorite) "Remove from favorites" else "Add to favorites")
        menu.menu.add(if (hidden) "Unhide" else "Hide")
        menu.menu.add("Add to Home screen")
        menu.menu.add("Uninstall")
        menu.setOnMenuItemClickListener { item ->
            when (item.title) {
                "Open" -> launch(entry)
                "App info" -> context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:${entry.app.packageName}"))
                )
                "Add to favorites", "Remove from favorites" -> {
                    FavoritesStore.toggleFavorite(context, entry.app.packageName, entry.app.activityName)
                    onChanged()
                }
                "Hide", "Unhide" -> {
                    HiddenAppsStore.setHidden(context, entry.app.packageName, !hidden)
                    onChanged()
                }
                "Add to Home screen" -> AppManagementRepository.requestPinShortcut(context, entry.app)
                "Uninstall" -> context.startActivity(
                    Intent(Intent.ACTION_DELETE).setData(Uri.parse("package:${entry.app.packageName}"))
                )
            }
            true
        }
        menu.show()
    }
}
