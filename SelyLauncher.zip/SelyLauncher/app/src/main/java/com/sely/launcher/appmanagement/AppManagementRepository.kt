package com.sely.launcher.appmanagement

import android.content.Context
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.os.Build
import com.sely.launcher.AppInfo
import com.sely.launcher.AppRepository

data class ManagedAppInfo(
    val app: AppInfo,
    val versionName: String?,
    val apkSizeBytes: Long
)

/**
 * Sely App Management (spec section 35) — data layer.
 *
 * 🟢 Version name via PackageManager (no permission needed).
 * 🟡 "App size" here is the installed APK file's size
 * (`File(sourceDir).length()`), shown honestly labeled as APK size —
 * NOT total storage used (which also includes app data/cache and would
 * need `StorageStatsManager`, gated behind the `PACKAGE_USAGE_STATS`
 * special permission — a much heavier ask than a launcher listing apps
 * should require just to show a size number).
 */
object AppManagementRepository {

    fun loadAll(context: Context): List<ManagedAppInfo> {
        val pm = context.packageManager
        return AppRepository.loadLaunchableApps(context).map { app ->
            val versionName = try {
                pm.getPackageInfo(app.packageName, 0).versionName
            } catch (e: Exception) { null }

            val sizeBytes = try {
                val appInfo = pm.getApplicationInfo(app.packageName, 0)
                java.io.File(appInfo.sourceDir).length()
            } catch (e: Exception) { 0L }

            ManagedAppInfo(app, versionName, sizeBytes)
        }
    }

    fun formatSize(bytes: Long): String {
        val mb = bytes / 1_048_576.0
        return if (mb >= 1) "%.1f MB".format(mb) else "%.0f KB".format(bytes / 1024.0)
    }

    /**
     * 🟢 Real official API (ShortcutManager.requestPinShortcut, API 26+)
     * that asks the current default launcher to add a pinned shortcut —
     * shows the system's own confirmation UI, exactly like any other
     * app's "Add to Home screen" action. No API exists below API 26 for
     * a general app to do this, so it's a no-op there.
     */
    fun requestPinShortcut(context: Context, app: AppInfo) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val shortcutManager = context.getSystemService(ShortcutManager::class.java)
        if (shortcutManager?.isRequestPinShortcutSupported != true) return

        val intent = android.content.Intent(android.content.Intent.ACTION_MAIN).apply {
            addCategory(android.content.Intent.CATEGORY_LAUNCHER)
            component = android.content.ComponentName(app.packageName, app.activityName)
        }
        val shortcut = ShortcutInfo.Builder(context, "sely_shortcut_${app.packageName}")
            .setShortLabel(app.label)
            .setIcon(Icon.createWithBitmap(app.icon.toBitmap()))
            .setIntent(intent)
            .build()
        shortcutManager.requestPinShortcut(shortcut, null)
    }

    private fun android.graphics.drawable.Drawable.toBitmap(): android.graphics.Bitmap {
        val width = intrinsicWidth.coerceAtLeast(1)
        val height = intrinsicHeight.coerceAtLeast(1)
        val bitmap = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        setBounds(0, 0, canvas.width, canvas.height)
        draw(canvas)
        return bitmap
    }
}
