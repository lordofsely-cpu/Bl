package com.sely.launcher.wallpaper

import android.content.Context

/**
 * Sely Wallpaper System — rotation set and saved effect settings.
 *
 * Rotation images are picked via ACTION_OPEN_DOCUMENT with
 * FLAG_GRANT_PERSISTABLE_URI_PERMISSION, and the app calls
 * takePersistableUriPermission() on each — the real, sanctioned way to
 * keep read access to a user-picked file across app restarts and
 * device reboots (a plain ACTION_GET_CONTENT Uri would NOT survive
 * that, so it's deliberately not used for the rotation set).
 */
object WallpaperRotationStore {
    private const val PREFS = "sely_wallpaper"
    private const val KEY_URIS = "rotation_uris"
    private const val KEY_INDEX = "rotation_index"
    private const val KEY_ENABLED = "rotation_enabled"
    private const val KEY_BLUR = "blur_strength"
    private const val KEY_DIM = "dim_percent"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getUris(context: Context): List<String> {
        val raw = prefs(context).getString(KEY_URIS, "") ?: ""
        return if (raw.isBlank()) emptyList() else raw.split("|")
    }

    fun setUris(context: Context, uris: List<String>) {
        prefs(context).edit().putString(KEY_URIS, uris.joinToString("|")).apply()
    }

    fun nextUri(context: Context): String? {
        val uris = getUris(context)
        if (uris.isEmpty()) return null
        val index = prefs(context).getInt(KEY_INDEX, 0) % uris.size
        prefs(context).edit().putInt(KEY_INDEX, (index + 1) % uris.size).apply()
        return uris[index]
    }

    fun rotationEnabled(context: Context) = prefs(context).getBoolean(KEY_ENABLED, false)
    fun setRotationEnabled(context: Context, enabled: Boolean) =
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()

    fun blurStrength(context: Context) = prefs(context).getInt(KEY_BLUR, 0)
    fun setBlurStrength(context: Context, value: Int) = prefs(context).edit().putInt(KEY_BLUR, value).apply()

    fun dimPercent(context: Context) = prefs(context).getInt(KEY_DIM, 0)
    fun setDimPercent(context: Context, value: Int) = prefs(context).edit().putInt(KEY_DIM, value).apply()
}
